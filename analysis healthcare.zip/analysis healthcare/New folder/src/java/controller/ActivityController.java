
package controller;

import dao.ActivityDAO;
import dto.ActivityDTO;
import dto.Login;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ActivityController {
    public String save(ActivityDTO activity,HttpServletRequest request,HttpServletResponse response) throws Exception{
        String ret="error";
        Login login=(Login)request.getSession(false).getAttribute("MYLOGIN");
        activity.setOwner(login.getUnm());
        activity.setStatus("not verify");
        activity.setDate(getDate(new Date()));
        ret=new dao.ActivityDAO().save(activity);
        response.sendRedirect("addactivity.jsp");
        return  ret;
    }
    public List<ActivityDTO> getActivity() throws Exception{
        return  new ActivityDAO().getActivity(new ActivityDTO("not verify"));
    }
    public String getDate(Date date){
        String stringDate="0000-00-00";
        stringDate=(date.getYear()+1900)+"-"+(date.getMonth()+1)+"-"+date.getDate();
        return stringDate;
    }
    public String update(HttpServletRequest request,HttpServletResponse response) throws Exception{
        String ret="error";
        ActivityDTO activity=new ActivityDTO();
        String code=request.getParameter("aId");
        activity.setaId(Integer.parseInt(code));
        activity.setStatus("verify");
        ret=new dao.ActivityDAO().update(activity);
        response.sendRedirect("admin.jsp");
        return  ret;
    }
}
