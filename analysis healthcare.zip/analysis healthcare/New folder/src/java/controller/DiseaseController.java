package controller;

import dao.*;
import dto.*;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import msg.MyMessage;


import java.util.Iterator;
import msg.MyMessage;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class DiseaseController {

    public void saveDisease(Disease disease, HttpServletRequest request, HttpServletResponse response) throws Exception {
        MyMessage myMessage = new MyMessage();
        String ret = "error";
        try {
            ret = new dao.DiseaseDAO().saveDisease(disease);
            if (ret.equalsIgnoreCase("success")) {
                myMessage.setDiseaseMessage("Record successfully saved");
                request.setAttribute("DISEASEMSG", myMessage);
                disease.setdId(DiseaseDAO.codeid);
                request.getSession(false).setAttribute("DISEASEID", "" + disease.getdId());
                request.getRequestDispatcher("diseasedetail.jsp").forward(request, response);

            } else {
                myMessage.setDiseaseMessage("Record not saved");
                request.setAttribute("DISEASEMSG", myMessage);
                request.getRequestDispatcher("adddisease.jsp").forward(request, response);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            try {
                myMessage.setDiseaseMessage("Server side error");
                request.setAttribute("DISEASEMSG", myMessage);
                request.getRequestDispatcher("adddisease.jsp").forward(request, response);

            } catch (Exception ex1) {
            }
        }
    }
    public void updatedDisease(Disease dto,HttpServletRequest request,HttpServletResponse response)throws Exception{
        new DiseaseDAO().updatedDisease(dto);
        request.getRequestDispatcher("diseasedetail.jsp").forward(request, response);
    }
    public void updatedDiseasePicture(String path, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        Disease disease = new DiseaseDAO().getDisease(new Disease(did));
        System.out.println(disease.getName());
        String contentType = request.getContentType();
        if ((contentType.indexOf("multipart/form-data") >= 0)) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            try {
                List fileItems = upload.parseRequest(request);
                Iterator i = fileItems.iterator();
                while (i.hasNext()) {
                    FileItem fi = (FileItem) i.next();
                    if (!fi.isFormField()) {
                        String filename = fi.getName();
                        String ext = filename.substring(filename.lastIndexOf("."), filename.length());
                        File create = new File(path + "disease image");
                        create.mkdir();
                        File file = new File(create.getPath() + "//" + disease.getdId() + ext);
                        fi.write(file);
                        disease.setImg("disease image/" + disease.getdId() + ext);

                        String ret = new dao.DiseaseDAO().updateDisease(disease);
                    }
                }

            } catch (Exception ex1) {
                ex1.printStackTrace();
            }
        }
        try {
            request.getRequestDispatcher("diseasedetail.jsp").forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public List<Disease> getAllDisease() throws Exception {
        return new DiseaseDAO().getAllDisease();
    }

    public Disease getDisease(HttpServletRequest request) throws Exception {
        String code = (String) request.getSession(false).getAttribute("DISEASEID");
        System.out.println(code);
        return new dao.DiseaseDAO().getDisease(new Disease(Integer.parseInt(code)));
    }

    public Disease getDisease(int dId) throws Exception {
        return new dao.DiseaseDAO().getDisease(new Disease(dId));
    }

    public List<Causes> getAllCauses(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new CausesDAO().getAll(did);
    }

    public List<DiagnosticTest> getAllDiagnosticTest(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new DiagnosticTestDAO().getAll(did);
    }

    public List<Medicine> getAllMedicine(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new MedicineDAO().getAll(did);
    }

    public List<Prevention> getAllPrevention(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new PreventionDAO().getAll(did);
    }

    public List<Symptoms> getAllSymptoms(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new SymptomsDAO().getAll(did);
    }

    public List<Treatment> getAllTreatment(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new TreatmentDAO().getAll(did);
    }

    public List<StatisticalDataDTO> getAllStatisticalData(HttpServletRequest request) throws Exception {
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did = Integer.parseInt(sesion);
        return new StatisticalDataDAO().getAll(did);
    }

    public List<ActivityDTO> getOurDiseaseActivity(ActivityDTO activitye, HttpServletRequest request) throws Exception {
        Login login = (Login) request.getSession(false).getAttribute("MYLOGIN");
        activitye.setOwner(login.getUnm());
        return new ActivityDAO().getOurDiseaseActivity(activitye);
    }
    public List<ActivityDTO> getOtherDiseaseActivity(ActivityDTO activitye) throws Exception {        
        return new ActivityDAO().getOtherDiseaseActivity(activitye);
    }
    public List<ActivityDTO> getOurActivity(HttpServletRequest request) throws Exception {
        Login login = (Login) request.getSession(false).getAttribute("MYLOGIN");
        return new ActivityDAO().getOurActivity(new ActivityDTO(login.getUnm(), null));
    }
}
