
package controller;
import dto.Symptoms;
import dao.SymptomsDAO;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import msg.MyMessage;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class SymptomsController {
    public void saveAcquiredDegree(HttpServletRequest request, HttpServletResponse response) {

        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did=Integer.parseInt(sesion);
        MyMessage myMessage=new MyMessage();
        String contentType = request.getContentType();
        if ((contentType.indexOf("multipart/form-data") >= 0)) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            try {

                new SymptomsDAO().delete(did);
                List fileItems = upload.parseRequest(request);
                Iterator i = fileItems.iterator();
                while (i.hasNext()) {
                    FileItem fi = (FileItem) i.next();
                    if (fi.isFormField()) {
                        String fieldName = fi.getFieldName();
                        System.out.println("fieldName : "+fieldName);
                        if(fieldName.startsWith("description")){
                           Symptoms symptoms=new Symptoms();
                            symptoms.setdId(did);
                            symptoms.setDescription(fi.getString());
                            new SymptomsDAO().saveAll(symptoms);
                        }
                    }
                }
                myMessage.setCausesMessage("Disease Symptoms Saved");
            } catch (Exception ex1) {
                myMessage.setCausesMessage("Disease Symptoms Not Saved");
            }
        }
        try{
            request.setAttribute("SYMPTOMMSG", myMessage);
            request.getRequestDispatcher("diseasedetail.jsp").forward(request, response);
        }catch(Exception ex){}
    }
}
