package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dto.MemberDTO;
import msg.MyMessage;

public class MemberController {

    public String saveMember(HttpServletRequest request, HttpServletResponse response, MemberDTO member) throws Exception {
        String ret = "error";
        ret = new dao.MemberDAO().saveMenber(member);
        if (ret.equalsIgnoreCase("error")) {
                MyMessage myMessage = new MyMessage();
                myMessage.setRegMessage("Registration failed");
                request.setAttribute("REGMSG", myMessage);
                request.getRequestDispatcher("index.jsp").forward(request, response);
        } else {
            if (ret.equalsIgnoreCase("success")) {
                response.sendRedirect("user.jsp");
            }
        }
        return ret;
    }
}
