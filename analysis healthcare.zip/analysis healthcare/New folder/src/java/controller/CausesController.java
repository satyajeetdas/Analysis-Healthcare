
package controller;

import dao.CausesDAO;
import java.util.List;
import dto.Causes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Iterator;
import msg.MyMessage;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


public class CausesController {
    public void saveAcquiredDegree(HttpServletRequest request, HttpServletResponse response) {
        
        String sesion = (String) request.getSession(false).getAttribute("DISEASEID");
        int did=Integer.parseInt(sesion);
        MyMessage myMessage=new MyMessage();
        String contentType = request.getContentType();
        if ((contentType.indexOf("multipart/form-data") >= 0)) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            try {
                
                new CausesDAO().delete(did);
                List fileItems = upload.parseRequest(request);
                Iterator i = fileItems.iterator();
                while (i.hasNext()) {
                    FileItem fi = (FileItem) i.next();
                    if (fi.isFormField()) {
                        String fieldName = fi.getFieldName();
                        System.out.println("fieldName : "+fieldName);
                        if(fieldName.startsWith("description")){
                            Causes causes=new Causes();
                            causes.setdId(did);
                            causes.setDescription(fi.getString());
                            new CausesDAO().saveAll(causes);
                        }
                    } 
                }
                myMessage.setCausesMessage("Disease Causes Saved");
            } catch (Exception ex1) {
                myMessage.setCausesMessage("Disease Causes Not Saved");
            }
        }
        try{
            request.setAttribute("CAUSESMSG", myMessage);
            request.getRequestDispatcher("diseasedetail.jsp").forward(request, response);
        }catch(Exception ex){}
    }
    
}
