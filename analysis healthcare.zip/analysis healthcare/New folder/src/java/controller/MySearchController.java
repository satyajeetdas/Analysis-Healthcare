package controller;

import dao.MySearchDAO;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MySearchController {
    public void search(HttpServletRequest request,HttpServletResponse response){
        try {
            List searchResultList=new ArrayList();
            String query = request.getParameter("search");
            query=query.toLowerCase();
            searchResultList=new MySearchDAO().search(query);
            request.setAttribute("SEARCHRESULT",searchResultList);
            request.getRequestDispatcher("user.jsp").forward(request, response);
        } catch (Exception ex) {
            try{
                request.setAttribute("SEARCHRESULT",new ArrayList<String>());
                request.getRequestDispatcher("user.jsp").forward(request, response);
            }catch(Exception ex1){}
            ex.printStackTrace();
        }
    }
}
