package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Login;
import javax.servlet.http.HttpSession;
import msg.MyMessage;

public class LoginController {

    public void loginVarify(HttpServletRequest request, HttpServletResponse response, Login login) {

        try {
            Login login1 = new dao.LoginDAO().loginVarify(login);
            if (login1 == null) {
                MyMessage myMessage = new MyMessage();
                myMessage.setLoginMessage("Invalid name or password");
                request.setAttribute("LOGINMSG", myMessage);
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } else {
                HttpSession https = request.getSession(true);
                https.setAttribute("MYLOGIN", login1);
                if (login1.getUl().equalsIgnoreCase("admin")) {
                    response.sendRedirect("admin.jsp");
                } else {
                    if (login1.getUl().equalsIgnoreCase("member")) {
                        response.sendRedirect("user.jsp");
                    }
                }
                

            }
        } catch (Exception ex) {
            ex.printStackTrace();
            try {
                MyMessage myMessage = new MyMessage();
                myMessage.setLoginMessage("Server side error");
                request.setAttribute("LOGINMSG", myMessage);
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } catch (Exception ex1) {
                ex1.printStackTrace();
            }
        }
    }
}
