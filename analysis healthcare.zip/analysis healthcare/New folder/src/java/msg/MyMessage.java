package msg;

public class MyMessage {

    private String loginMessage;
    private String diseaseMessage;
    private String causesMessage;
    private String diagnostictestMessage;
    private String medicineMessage;
    private String preventionMessage;
    private String symptomsMessage;
    private String treatmentMessage;
    private String regMessage;

    public String getRegMessage() {
        return regMessage;
    }

    public void setRegMessage(String regMessage) {
        this.regMessage = regMessage;
    }

    public String getCausesMessage() {
        return causesMessage;
    }

    public void setCausesMessage(String causesMessage) {
        this.causesMessage = causesMessage;
    }

    public String getDiagnostictestMessage() {
        return diagnostictestMessage;
    }

    public void setDiagnostictestMessage(String diagnostictestMessage) {
        this.diagnostictestMessage = diagnostictestMessage;
    }

    public String getMedicineMessage() {
        return medicineMessage;
    }

    public void setMedicineMessage(String medicineMessage) {
        this.medicineMessage = medicineMessage;
    }

    public String getPreventionMessage() {
        return preventionMessage;
    }

    public void setPreventionMessage(String preventionMessage) {
        this.preventionMessage = preventionMessage;
    }

    public String getSymptomsMessage() {
        return symptomsMessage;
    }

    public void setSymptomsMessage(String symptomsMessage) {
        this.symptomsMessage = symptomsMessage;
    }

    public String getTreatmentMessage() {
        return treatmentMessage;
    }

    public void setTreatmentMessage(String treatmentMessage) {
        this.treatmentMessage = treatmentMessage;
    }

    public String getDiseaseMessage() {
        return diseaseMessage;
    }

    public void setDiseaseMessage(String diseaseMessage) {
        this.diseaseMessage = diseaseMessage;
    }

    public MyMessage() {
    }

    public MyMessage(String loginMessage) {
        this.loginMessage = loginMessage;
    }

    public String getLoginMessage() {
        return loginMessage;
    }

    public void setLoginMessage(String loginMessage) {
        this.loginMessage = loginMessage;
    }
}
