package dto;

public class ActivityDTO {

    private int aId;
    private String description;
    private int dId;
    private String owner;
    private String status;
    private String date;

    public ActivityDTO(int dId) {
        this.dId = dId;
    }

    public ActivityDTO(String owner, String date) {
        this.owner = owner;
        this.date = date;
    }

    public ActivityDTO() {
    }

    public ActivityDTO(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getaId() {
        return aId;
    }

    public void setaId(int aId) {
        this.aId = aId;
    }

    public int getdId() {
        return dId;
    }

    public void setdId(int dId) {
        this.dId = dId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
