
package dto;


public class DiagnosticTest {
    private int dTId;
    private int dId;
    private String description;

    public int getdId() {
        return dId;
    }

    public void setdId(int dId) {
        this.dId = dId;
    }

    public int getdTId() {
        return dTId;
    }

    public void setdTId(int dTId) {
        this.dTId = dTId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
