
package dao;
import dto.Disease;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DiseaseDAO {
    public static int codeid;
    public String updatedDisease(Disease disease)throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("update disease set history='"+disease.getHistory()+"',description='"+disease.getDescription()+"' where dId='"+disease.getdId()+"'");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public String saveDisease(Disease disease) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into disease (name,history,description) values ('"+disease.getName()+"','"+disease.getHistory()+"','"+disease.getDescription()+"')");
            st.close();
            st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from disease where name='"+disease.getName()+"' and history='"+disease.getHistory()+"' and description='"+disease.getDescription()+"'");
            if(rs.next()){
                codeid=rs.getInt("dId");
            }
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public String updateDisease(Disease disease) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("update disease set img='"+disease.getImg()+"' ,name='"+disease.getName()+"',history='"+disease.getHistory()+"',description='"+disease.getDescription()+"' where dId='"+disease.getdId()+"'");
            st.close();            
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public Disease getDisease(Disease disease) throws Exception{
        Disease disease1=new Disease();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from disease where dId="+disease.getdId());
            if(rs.next()){
                disease1.setdId(rs.getInt("dId"));
                disease1.setName(rs.getString("name"));
                disease1.setDescription(rs.getString("description"));
                disease1.setHistory(rs.getString("history"));
                disease1.setImg(rs.getString("img"));
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return disease1;
    }

    public List<Disease> getAllDisease() throws Exception{
        List<Disease> list=new ArrayList<Disease>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from disease order by name");
            while(rs.next()){
                Disease disease=new Disease();
                disease.setdId(rs.getInt("dId"));
                disease.setName(rs.getString("name"));
                disease.setDescription(rs.getString("description"));
                disease.setHistory("history");
                list.add(disease);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
}
