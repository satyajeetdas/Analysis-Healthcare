
package dao;

import dto.Symptoms;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class SymptomsDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from symptoms where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<Symptoms> getAll(int myid) throws Exception{
        List <Symptoms>list=new ArrayList<Symptoms>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from symptoms where dId="+myid);
            while(rs.next()){
                Symptoms symptoms=new Symptoms();
                symptoms.setsId(rs.getInt("sId"));
                symptoms.setdId(rs.getInt("dId"));
                symptoms.setDescription(rs.getString("description"));
                list.add(symptoms);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(Symptoms symptoms) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into symptoms (dId,description) values ('"+symptoms.getdId()+"','"+symptoms.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    
}
