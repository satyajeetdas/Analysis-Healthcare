
package dao;

import java.sql.Connection;
import java.sql.Statement;
import dto.Medicine;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MedicineDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from medicine where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<Medicine> getAll(int myid) throws Exception{
        List <Medicine>list=new ArrayList<Medicine>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from medicine where dId="+myid);
            while(rs.next()){
                Medicine medicine=new Medicine();
                medicine.setmId(rs.getInt("mId"));
                medicine.setdId(rs.getInt("dId"));
                medicine.setDescription(rs.getString("description"));
                list.add(medicine);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(Medicine medicine) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into medicine (dId,description) values ('"+medicine.getdId()+"','"+medicine.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    
}
