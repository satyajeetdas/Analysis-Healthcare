

package dao;

import java.sql.Connection;
import java.sql.Statement;
import dto.Treatment;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class TreatmentDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from treatment where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<Treatment> getAll(int myid) throws Exception{
        List <Treatment>list=new ArrayList<Treatment>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from treatment where dId="+myid);
            while(rs.next()){
                Treatment treatment=new Treatment();
                treatment.settId(rs.getInt("tId"));
                treatment.setdId(rs.getInt("dId"));
                treatment.setDescription(rs.getString("description"));
                list.add(treatment);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(Treatment treatment) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into treatment (dId,description) values ('"+treatment.getdId()+"','"+treatment.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    
}
