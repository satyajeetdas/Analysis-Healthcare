
package dao;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import dto.Causes;
import java.sql.ResultSet;
import java.util.ArrayList;



public class CausesDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from causes where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<Causes> getAll(int myid) throws Exception{
        List <Causes>list=new ArrayList<Causes>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from causes where dId="+myid);
            while(rs.next()){
                Causes causes=new Causes();
                causes.setcId(rs.getInt("cId"));
                causes.setdId(rs.getInt("dId"));
                causes.setDescription(rs.getString("description"));
                list.add(causes);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(Causes causes) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into causes (dId,description) values ('"+causes.getdId()+"','"+causes.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
}
