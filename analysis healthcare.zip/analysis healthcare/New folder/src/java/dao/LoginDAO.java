
package dao;

import dto.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class LoginDAO {
    public Login loginVarify(Login login) throws Exception{
        Login login1=null;
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from login where unm='"+login.getUnm()+"' and up='"+login.getUp()+"'");
            if(rs.next()){
                String level=rs.getString("ul");
                login.setUl(level);
                login1=login;
                System.out.println(login1);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        System.out.println(login1);
        return login1;
    }
    
}
