package dao;
import dto.StatisticalDataDTO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StatisticalDataDAO {

    public String delete(int myid) throws Exception {
        String ret = "error";
        Connection con = null;
        try {
            con = new db.MyConnection().getConnection();
            Statement st = con.createStatement();
            st.executeUpdate("delete from statisticaldata where dId=" + myid);
            st.close();
            ret = "success";
        } finally {
            con.close();
        }
        return ret;
    }

    public List<StatisticalDataDTO> getAll(int myid) throws Exception {
        List<StatisticalDataDTO> list = new ArrayList<StatisticalDataDTO>();
        Connection con = null;
        try {
            con = new db.MyConnection().getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from statisticaldata where dId=" + myid);
            while (rs.next()) {
                StatisticalDataDTO dTO = new StatisticalDataDTO();
                dTO.setsDId(rs.getInt("sDId"));
                dTO.setdId(rs.getInt("dId"));
                dTO.setDescription(rs.getString("description"));
                list.add(dTO);
            }
            rs.close();
            st.close();
        } finally {
            con.close();
        }
        return list;
    }

    public String saveAll(StatisticalDataDTO dTO) throws Exception {
        String ret = "error";
        Connection con = null;
        try {
            con = new db.MyConnection().getConnection();
            Statement st = con.createStatement();
            st.executeUpdate("insert into statisticaldata (dId,description) values ('" + dTO.getdId() + "','" + dTO.getDescription() + "')");
            st.close();
            ret = "success";
        } finally {
            con.close();
        }
        return ret;
    }
}
