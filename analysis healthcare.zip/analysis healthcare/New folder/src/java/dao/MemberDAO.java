
package dao;
import dto.MemberDTO;
import java.sql.Connection;
import java.sql.Statement;

public class MemberDAO {
    public String saveMenber(MemberDTO member)throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            con.setAutoCommit(false);
            Statement st = con.createStatement();
            st.execute("insert into member(name,fname,dob,email,mno,address,disease,dri,specialization)values('"+member.getName()+"','"+member.getFname()+"','"+member.getDob()+"','"+member.getEmail()+"','"+member.getMno()+"','"+member.getAddress()+"','"+member.getDisease()+"','"+member.getDrid()+"','"+member.getSpecialization()+"')");
            st.close();

            st = con.createStatement();
            st.execute("insert into login(unm,up,ul)values('"+member.getEmail()+"','"+member.getPassword()+"','member')");
            st.close();

            con.commit();
            ret="success";
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            con.close();
        }
        return ret;
    }
}
