
package dao;
import dto.DiagnosticTest;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DiagnosticTestDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from diagnostictest where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<DiagnosticTest> getAll(int myid) throws Exception{
        List <DiagnosticTest>list=new ArrayList<DiagnosticTest>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from diagnostictest where dId="+myid);
            while(rs.next()){
                DiagnosticTest diagnosticTest=new DiagnosticTest();
                diagnosticTest.setdTId(rs.getInt("dTId"));
                diagnosticTest.setdId(rs.getInt("dId"));
                diagnosticTest.setDescription(rs.getString("description"));
                list.add(diagnosticTest);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(DiagnosticTest diagnosticTest) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into diagnostictest (dId,description) values ('"+diagnosticTest.getdId()+"','"+diagnosticTest.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
}
