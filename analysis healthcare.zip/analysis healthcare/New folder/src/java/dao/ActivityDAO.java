
package dao;

import com.sun.jmx.remote.internal.ArrayQueue;
import dto.ActivityDTO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ActivityDAO {
    public String save(ActivityDTO activity) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.execute("insert into activity (dId,description,owner,status,date) values ('"+activity.getdId()+"','"+activity.getDescription()+"','"+activity.getOwner()+"','"+activity.getStatus()+"','"+activity.getDate()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<ActivityDTO> getActivity(ActivityDTO activity) throws Exception{
        List<ActivityDTO> list=new ArrayList<ActivityDTO>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs = st.executeQuery("select * from activity where status='" + activity.getStatus() + "' ");
            while(rs.next()){
                ActivityDTO dTO=new ActivityDTO();
                dTO.setaId(rs.getInt("aId"));
                dTO.setdId(rs.getInt("dId"));
                dTO.setDescription(rs.getString("description"));
                dTO.setOwner(rs.getString("owner"));
                dTO.setStatus(rs.getString("status"));
                dTO.setDate(rs.getString("date"));
                list.add(dTO);
            }
            st.close();
            
        }finally{
            con.close();
        }
        return  list;
    }
    public List<ActivityDTO> getOurDiseaseActivity(ActivityDTO activity) throws Exception{
        List<ActivityDTO> list=new ArrayList<ActivityDTO>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            String query="select * from activity where owner='" + activity.getOwner() + "' and dId='" + activity.getdId() + "' ";
            //System.out.println(query);
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                ActivityDTO dTO=new ActivityDTO();
                dTO.setaId(rs.getInt("aId"));
                dTO.setdId(rs.getInt("dId"));
                dTO.setDescription(rs.getString("description"));
                dTO.setOwner(rs.getString("owner"));
                dTO.setStatus(rs.getString("status"));
                dTO.setDate(rs.getString("date"));
                list.add(dTO);
            }
            st.close();

        }finally{
            con.close();
        }
        return  list;
    }
    public List<ActivityDTO> getOtherDiseaseActivity(ActivityDTO activity) throws Exception{
        List<ActivityDTO> list=new ArrayList<ActivityDTO>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            String query="select * from activity where dId='" + activity.getdId() + "' ";
            //System.out.println(query);
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                ActivityDTO dTO=new ActivityDTO();
                dTO.setaId(rs.getInt("aId"));
                dTO.setdId(rs.getInt("dId"));
                dTO.setDescription(rs.getString("description"));
                dTO.setOwner(rs.getString("owner"));
                dTO.setStatus(rs.getString("status"));
                dTO.setDate(rs.getString("date"));
                list.add(dTO);
            }
            st.close();

        }finally{
            con.close();
        }
        return  list;
    }
    public List<ActivityDTO> getOurActivity(ActivityDTO activity) throws Exception{
        List<ActivityDTO> list=new ArrayList<ActivityDTO>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            String query="select * from activity where owner='" + activity.getOwner() + "' ";
            System.out.println(query);
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                ActivityDTO dTO=new ActivityDTO();
                dTO.setaId(rs.getInt("aId"));
                dTO.setdId(rs.getInt("dId"));
                dTO.setDescription(rs.getString("description"));
                dTO.setOwner(rs.getString("owner"));
                dTO.setStatus(rs.getString("status"));
                dTO.setDate(rs.getString("date"));
                list.add(dTO);
            }
            st.close();

        }catch(Exception e){
            e.printStackTrace();
        }finally{
            con.close();
        }
        return  list;
    }

    public String update(ActivityDTO activity) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("update activity set status='"+activity.getStatus()+"' where aId='"+activity.getaId()+"'");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
}
