package dao;

import dto.SearchResult;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MySearchDAO {
    public List search(String query) throws Exception{
        List searchResultList=new ArrayList();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from mysearch");
            String q="";
            String diseaseName="";

            while(rs.next()){
                String statement=rs.getString("statement");
                System.out.println(query+" : "+statement);
                if(query.contains(statement)){                                          
                    statement=statement.trim();
                    statement=statement.toLowerCase();
                    List <String>values1=new ArrayList<String>();
                    values1.add("causes of");
                    values1.add("cure of");
                    values1.add("prevention of");
                    values1.add("symptom of");
                    values1.add("treatment of");
                    values1.add("history of");
                    values1.add("diagnosis of");
                    values1.add("drugs of");
                    values1.add("what is");
                    if(values1.contains(statement)){
                        int start=query.indexOf(statement);
                        String q1=rs.getString("query");
                        String q2=rs.getString("subquery");
                        String q3=rs.getString("endmarker");
                        diseaseName=query.substring(start+statement.length(),query.length());
                        diseaseName=diseaseName.trim();
                        q=q1+q2;
                        q=q+diseaseName;
                        q=q+q3;
                    }
                    List <String>values2=new ArrayList<String>();
                    values2.add("anemia");

                    if(values2.contains(query)){                        
                        String q1=rs.getString("query");
                        String q2=rs.getString("subquery");
                        String q3=rs.getString("endmarker");
                        q=q1+q2;
                        q=q+query;
                        q=q+q3;
                    }
                    List <String>value3=new ArrayList<String>();
                    value3.add("define");
                    value3.add("explain");
                    for(String word:value3){
                        if(query.startsWith(word)){
                            String q1=rs.getString("query");
                            query=query.substring(query.indexOf(word)+word.length(),query.length());
                            query=query.trim();
                            String q2=rs.getString("subquery");
                            String q3=rs.getString("endmarker");
                            q=q1+q2;
                            q=q+query;
                            q=q+q3;
                            break;
                        }
                    }
                    break;
                }
            }
            if(q.equalsIgnoreCase("")){
                q="select * from disease where name like '"+query+"%'";
            }

//            Statement st3=con.createStatement();
//            ResultSet rs3=st3.executeQuery("select * from disease where name like '"+query+"'%");
//            if(rs3.next()){
//                rs3.getString("");
//            }
//            rs3.close();
//            st3.close();

            rs.close();
            st.close();
            
            Statement st1=con.createStatement();
            ResultSet rs1=st1.executeQuery(q);

            int flag=0;
            while(rs1.next()){
                flag=1;
                SearchResult searchResult=new SearchResult();
                String desc="";
                System.out.println("History Test : "+q);
                if(query.contains("history")){
                    desc=rs1.getString("history");
                }
                else
                {
                    desc=rs1.getString("description");
                }
                searchResult.setDescription(desc);
                searchResultList.add(searchResult);
            }
            rs1.close();
            st1.close();
            if(flag==0){
                Statement st2=con.createStatement();
                ResultSet rs2=st2.executeQuery("select * from disease");
                while (rs2.next()) {
                    String name = rs2.getString("name");
                    name=name.toLowerCase();
                    //System.out.println("query : "+query);
                    //System.out.println("name  : "+name);
                    if (query.contains(name)) {
                        int did = rs2.getInt("dId");
                        String q1 = "select * from statisticaldata where dId = " + did;
                        Statement st3 = con.createStatement();
                        ResultSet rs3 = st3.executeQuery(q1);
                        while (rs3.next()) {                            
                            SearchResult searchResult = new SearchResult();
                            String desc = "";
                            desc = rs3.getString("description");
                            searchResult.setDescription(desc);
                            searchResultList.add(searchResult);
                        }
                        rs3.close();
                        st3.close();
                        break;
                    }
                }
                rs2.close();
                st2.close();

            }
            
            //System.out.println("Query : "+q);
        }finally{
            con.close();
        }
        return searchResultList;
    }
}
