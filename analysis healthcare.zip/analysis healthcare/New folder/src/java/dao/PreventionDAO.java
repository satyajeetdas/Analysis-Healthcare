

package dao;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import dto.Prevention;
import java.sql.ResultSet;


public class PreventionDAO {
    public String delete(int myid) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("delete from prevention where dId="+myid);
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    public List<Prevention> getAll(int myid) throws Exception{
        List <Prevention>list=new ArrayList<Prevention>();
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from prevention where dId="+myid);
            while(rs.next()){
                Prevention prevention=new Prevention();
                prevention.setpId(rs.getInt("pId"));
                prevention.setdId(rs.getInt("dId"));
                prevention.setDescription(rs.getString("description"));
                list.add(prevention);
            }
            rs.close();
            st.close();
        }finally{
            con.close();
        }
        return list;
    }
    public String saveAll(Prevention prevention) throws Exception{
        String ret="error";
        Connection con=null;
        try{
            con=new db.MyConnection().getConnection();
            Statement st=con.createStatement();
            st.executeUpdate("insert into prevention (dId,description) values ('"+prevention.getdId()+"','"+prevention.getDescription()+"')");
            st.close();
            ret="success";
        }finally{
            con.close();
        }
        return  ret;
    }
    
}
